# LLM Content Detector

A Chrome extension that helps detect potential LLM-generated content on web pages by looking for specific patterns, words, and phrases commonly used by language models. Written by RSnake.

## Features

- Detects suspicious words like "delve", "significantly", "highlighted", etc.
- Identifies common LLM patterns like "it's not just about... it's"
- Highlights em dashes (—) which are often used by LLMs
- Visual highlighting of detected content on the page
- Popup interface showing detailed detection results

## Installation

1. Clone this repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Build the extension:
   ```bash
   npm run build
   ```
4. Load the extension in Chrome:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the `dist` directory from this project

## Usage

1. Click the extension icon in your browser toolbar to see detection results
2. Detected content will be highlighted in red on the page
3. Hover over highlighted content to see more details

## Development

- Run `npm run watch` to automatically compile TypeScript files as you make changes
- The extension will need to be reloaded in Chrome after making changes

## License

BSD 